package de.maria.bus55

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Виджет: автобус 55
 *  - Waldheimplatz → Ostbahnhof
 *  - Neuperlach Zentrum → Putzbrunn / Waldperlach
 * Данные — открытый API MVG (тот же, что использует mvg.de/meinhalt).
 * Обновление: по нажатию на виджет + автоматически раз в 30 минут.
 */
class BusWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        refresh(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) refresh(context)
    }

    private fun refresh(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences("bus55", Context.MODE_PRIVATE)
        lastOst = prefs.getString("ost", lastOst) ?: lastOst
        lastBack = prefs.getString("back", lastBack) ?: lastBack
        push(app, views(app, "обновляю…"))
        val pending = goAsync()
        Thread {
            try {
                val toOst = withRetry { load(WALDHEIMPLATZ) { it.contains("Ostbahnhof") } }
                val back = withRetry { load(NEUPERLACH) { it.contains("Putzbrunn") || it.contains("Waldperlach") } }
                lastOst = format(toOst, withDest = false)
                lastBack = format(back, withDest = true)
                prefs.edit().putString("ost", lastOst).putString("back", lastBack).apply()
                push(app, views(app, "обновлено ${hhmm(System.currentTimeMillis())} · ~ по расписанию"))
            } catch (e: Exception) {
                val why = "${e.javaClass.simpleName}: ${e.message ?: ""}".take(90)
                push(app, views(app, "ошибка ${hhmm(System.currentTimeMillis())} — $why"))
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun <T> withRetry(block: () -> T): T =
        try { block() } catch (e: Exception) { Thread.sleep(1500); block() }

    private data class Dep(val time: Long, val delay: Int, val realtime: Boolean, val dest: String)

    private fun load(station: String, matchDest: (String) -> Boolean): List<Dep> {
        val url = URL("https://www.mvg.de/api/bgw-pt/v3/departures?globalId=$station&limit=100&transportTypes=BUS")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 8_000
        conn.readTimeout = 8_000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Bus55Widget")
        conn.setRequestProperty("Accept", "application/json")
        try {
            val code = conn.responseCode
            if (code != 200) throw java.io.IOException("HTTP $code")
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body)
            val now = System.currentTimeMillis()
            val out = mutableListOf<Dep>()
            for (i in 0 until arr.length()) {
                val d = arr.getJSONObject(i)
                val dest = d.optString("destination")
                val t = d.optLong("realtimeDepartureTime")
                if (d.optString("label") != LINE) continue
                if (d.optBoolean("cancelled")) continue
                if (!matchDest(dest)) continue
                if (t < now - 30_000) continue
                out += Dep(t, d.optInt("delayInMinutes", 0), d.optBoolean("realtime"), dest)
            }
            return out.sortedBy { it.time }.take(SHOW)
        } finally {
            conn.disconnect()
        }
    }

    private fun format(list: List<Dep>, withDest: Boolean): String {
        if (list.isEmpty()) return "нет рейсов"
        return list.joinToString("\n") { d ->
            val mark = if (d.realtime) "" else "~"
            val delay = if (d.delay > 0) " +${d.delay}" else ""
            val dest = if (withDest) "  " + d.dest.substringBefore(",") else ""
            "$mark${hhmm(d.time)}$delay$dest"
        }
    }

    private fun views(context: Context, status: String): RemoteViews {
        val intent = Intent(context, BusWidget::class.java).setAction(ACTION_REFRESH)
        val pi = PendingIntent.getBroadcast(
            context, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return RemoteViews(context.packageName, R.layout.widget).apply {
            setTextViewText(R.id.ost_list, lastOst)
            setTextViewText(R.id.back_list, lastBack)
            setTextViewText(R.id.status, status)
            setOnClickPendingIntent(R.id.root, pi)
        }
    }

    private fun push(context: Context, views: RemoteViews) {
        AppWidgetManager.getInstance(context)
            .updateAppWidget(ComponentName(context, BusWidget::class.java), views)
    }

    companion object {
        const val ACTION_REFRESH = "de.maria.bus55.REFRESH"
        private const val LINE = "55"
        private const val WALDHEIMPLATZ = "de:09162:966"
        private const val NEUPERLACH = "de:09162:1030"
        private const val SHOW = 4

        @Volatile private var lastOst = "…"
        @Volatile private var lastBack = "…"

        private fun hhmm(ms: Long): String =
            SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date(ms))
    }
}
