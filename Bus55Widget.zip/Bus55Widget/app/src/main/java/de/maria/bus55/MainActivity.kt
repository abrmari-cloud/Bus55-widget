package de.maria.bus55

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(TextView(this).apply {
            setPadding(48, 96, 48, 48)
            textSize = 18f
            text = "Виджет установлен.\n\nДолгое нажатие на главном экране → Виджеты → «Bus 55».\n\nНажатие на виджет обновляет данные."
        })
    }
}
